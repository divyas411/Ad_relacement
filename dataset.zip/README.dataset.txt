# billboard > 2024-10-13 11:29pm
https://universe.roboflow.com/divya-jain/billboard-h6gbv

Provided by a Roboflow user
License: CC BY 4.0

